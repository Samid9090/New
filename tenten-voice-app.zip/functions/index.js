const functions = require("firebase-functions")
const admin = require("firebase-admin")

admin.initializeApp()

// Send notification when friend request is created
exports.sendFriendRequestNotification = functions.firestore
  .document("friend_requests/{requestId}")
  .onCreate(async (snap, context) => {
    const requestData = snap.data()

    try {
      // Get target user's FCM token
      const targetUserDoc = await admin.firestore().collection("users").doc(requestData.to).get()

      const targetUser = targetUserDoc.data()

      // Get sender user's data
      const senderUserDoc = await admin.firestore().collection("users").doc(requestData.from).get()

      const senderUser = senderUserDoc.data()

      if (targetUser?.fcmToken) {
        const message = {
          token: targetUser.fcmToken,
          notification: {
            title: "New Friend Request",
            body: `${senderUser.name} wants to be your friend`,
          },
          data: {
            type: "friend_request",
            requestId: context.params.requestId,
            fromUserId: requestData.from,
          },
        }

        await admin.messaging().send(message)
        console.log("Friend request notification sent")
      }
    } catch (error) {
      console.error("Error sending notification:", error)
    }
  })

// Send notification when friend request is accepted
exports.sendFriendRequestAcceptedNotification = functions.firestore
  .document("friend_requests/{requestId}")
  .onUpdate(async (change, context) => {
    const beforeData = change.before.data()
    const afterData = change.after.data()

    // Check if status changed to accepted
    if (beforeData.status === "pending" && afterData.status === "accepted") {
      try {
        // Get sender user's FCM token
        const senderUserDoc = await admin.firestore().collection("users").doc(afterData.from).get()

        const senderUser = senderUserDoc.data()

        // Get accepter user's data
        const accepterUserDoc = await admin.firestore().collection("users").doc(afterData.to).get()

        const accepterUser = accepterUserDoc.data()

        if (senderUser?.fcmToken) {
          const message = {
            token: senderUser.fcmToken,
            notification: {
              title: "Friend Request Accepted",
              body: `${accepterUser.name} accepted your friend request`,
            },
            data: {
              type: "friend_request_accepted",
              friendUserId: afterData.to,
            },
          }

          await admin.messaging().send(message)
          console.log("Friend request accepted notification sent")
        }
      } catch (error) {
        console.error("Error sending notification:", error)
      }
    }
  })
