-- Firestore Security Rules
-- Copy this to Firebase Console > Firestore Database > Rules

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Users can read all user profiles but only write their own
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Friend requests - users can read requests they're involved in
    match /friend_requests/{requestId} {
      allow read: if request.auth != null && 
        (request.auth.uid == resource.data.from || 
         request.auth.uid == resource.data.to);
      allow create: if request.auth != null && 
        request.auth.uid == request.resource.data.from;
      allow update: if request.auth != null && 
        request.auth.uid == resource.data.to;
      allow delete: if request.auth != null && 
        (request.auth.uid == resource.data.from || 
         request.auth.uid == resource.data.to);
    }
    
    // Presence data - users can read all but only write their own
    match /presence/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // WebRTC signaling data - temporary data for peer connections
    match /signaling/{sessionId} {
      allow read, write: if request.auth != null;
    }
  }
}
