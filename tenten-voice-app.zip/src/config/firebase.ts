// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app"
import { getAnalytics } from "firebase/analytics"
import { getAuth } from "firebase/auth"
import { getFirestore } from "firebase/firestore"
import { getStorage } from "firebase/storage"
import { getDatabase } from "firebase/database" // For WebRTC signaling

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDQdXA7FltP6n4XG-6lMQRa_bLqYAV1BH0",
  authDomain: "push-dery.firebaseapp.com",
  projectId: "push-dery",
  storageBucket: "push-dery.firebasestorage.app",
  messagingSenderId: "713532860414",
  appId: "1:713532860414:web:dcb32199fbc56742d202af",
  measurementId: "G-T96JRLHVM7",
}

// Initialize Firebase
const app = initializeApp(firebaseConfig)

// Initialize Firebase services
export const analytics = getAnalytics(app)
export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)
export const realtimeDb = getDatabase(app) // For WebRTC signaling

export default app
