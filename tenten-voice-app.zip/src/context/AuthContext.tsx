"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import type { User } from "firebase/auth"
import { doc, getDoc, updateDoc } from "firebase/firestore"
import { auth, db } from "../config/firebase"
import { requestNotificationPermission, setupForegroundMessageListener } from "../services/fcm"

interface UserProfile {
  uid: string
  name: string
  username: string
  pin: string
  profilePic?: string
  email: string
  friends: string[]
  fcmToken?: string
  online: boolean
  lastSeen: Date
}

interface AuthContextType {
  user: User | null
  userProfile: UserProfile | null
  loading: boolean
  updateUserProfile: (data: Partial<UserProfile>) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      setUser(user)
      if (user) {
        await loadUserProfile(user.uid)

        // Setup FCM for push notifications
        try {
          await requestNotificationPermission(user.uid)
          setupForegroundMessageListener()
        } catch (error) {
          console.error("FCM setup error:", error)
        }
      } else {
        setUserProfile(null)
      }
      setLoading(false)
    })

    return unsubscribe
  }, [])

  const loadUserProfile = async (uid: string) => {
    try {
      const docRef = doc(db, "users", uid)
      const docSnap = await getDoc(docRef)

      if (docSnap.exists()) {
        setUserProfile(docSnap.data() as UserProfile)
      }
    } catch (error) {
      console.error("Error loading user profile:", error)
    }
  }

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    if (!user) return

    try {
      const docRef = doc(db, "users", user.uid)
      await updateDoc(docRef, data)

      if (userProfile) {
        setUserProfile({ ...userProfile, ...data })
      }
    } catch (error) {
      console.error("Error updating user profile:", error)
    }
  }

  return (
    <AuthContext.Provider value={{ user, userProfile, loading, updateUserProfile }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
