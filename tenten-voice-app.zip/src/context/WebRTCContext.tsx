"use client"

import type React from "react"
import { createContext, useContext, useRef, useState, useEffect } from "react"
import { RTCPeerConnection, mediaDevices } from "react-native-webrtc"
import { ref, push, onValue, set, off } from "firebase/database"
import { realtimeDb } from "../config/firebase"
import { useAuth } from "./AuthContext"

interface WebRTCContextType {
  isStreaming: boolean
  startVoiceStream: (targetUserId: string) => Promise<void>
  stopVoiceStream: () => void
  isReceiving: boolean
}

const WebRTCContext = createContext<WebRTCContextType | undefined>(undefined)

export function WebRTCProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  const [isStreaming, setIsStreaming] = useState(false)
  const [isReceiving, setIsReceiving] = useState(false)
  const peerConnection = useRef<RTCPeerConnection | null>(null)
  const localStream = useRef<any>(null)
  const signalingRef = useRef<any>(null)

  const configuration = {
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }],
  }

  const startVoiceStream = async (targetUserId: string) => {
    if (!user) return

    try {
      // Get user media (microphone)
      const stream = await mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
        video: false,
      })

      localStream.current = stream

      // Create peer connection
      peerConnection.current = new RTCPeerConnection(configuration)

      // Add local stream to peer connection
      stream.getTracks().forEach((track) => {
        peerConnection.current?.addTrack(track, stream)
      })

      // Setup signaling channel
      const sessionId = `${user.uid}_${targetUserId}_${Date.now()}`
      signalingRef.current = ref(realtimeDb, `signaling/${sessionId}`)

      // Handle ICE candidates
      peerConnection.current.onicecandidate = (event) => {
        if (event.candidate) {
          const candidateRef = ref(realtimeDb, `signaling/${sessionId}/candidates`)
          push(candidateRef, {
            candidate: event.candidate,
            from: user.uid,
            timestamp: Date.now(),
          })
        }
      }

      // Handle remote stream
      peerConnection.current.ontrack = (event) => {
        console.log("Received remote stream")
        setIsReceiving(true)
        // Auto-play remote audio stream
        const remoteAudio = new Audio()
        remoteAudio.srcObject = event.streams[0]
        remoteAudio.play()
      }

      // Create and send offer
      const offer = await peerConnection.current.createOffer()
      await peerConnection.current.setLocalDescription(offer)

      // Send offer via Firebase
      await set(ref(realtimeDb, `signaling/${sessionId}/offer`), {
        offer: offer,
        from: user.uid,
        to: targetUserId,
        timestamp: Date.now(),
      })

      // Listen for answer
      const answerRef = ref(realtimeDb, `signaling/${sessionId}/answer`)
      onValue(answerRef, async (snapshot) => {
        const answerData = snapshot.val()
        if (answerData && answerData.to === user.uid) {
          await peerConnection.current?.setRemoteDescription(answerData.answer)
        }
      })

      // Listen for ICE candidates
      const candidatesRef = ref(realtimeDb, `signaling/${sessionId}/candidates`)
      onValue(candidatesRef, (snapshot) => {
        const candidates = snapshot.val()
        if (candidates) {
          Object.values(candidates).forEach(async (candidateData: any) => {
            if (candidateData.from !== user.uid) {
              await peerConnection.current?.addIceCandidate(candidateData.candidate)
            }
          })
        }
      })

      setIsStreaming(true)
    } catch (error) {
      console.error("Error starting voice stream:", error)
    }
  }

  const stopVoiceStream = () => {
    if (localStream.current) {
      localStream.current.getTracks().forEach((track: any) => track.stop())
      localStream.current = null
    }

    if (peerConnection.current) {
      peerConnection.current.close()
      peerConnection.current = null
    }

    if (signalingRef.current) {
      off(signalingRef.current)
      signalingRef.current = null
    }

    setIsStreaming(false)
    setIsReceiving(false)
  }

  // Listen for incoming calls
  useEffect(() => {
    if (!user) return

    const incomingCallsRef = ref(realtimeDb, `signaling`)
    const unsubscribe = onValue(incomingCallsRef, (snapshot) => {
      const sessions = snapshot.val()
      if (sessions) {
        Object.entries(sessions).forEach(([sessionId, sessionData]: [string, any]) => {
          if (sessionData.offer && sessionData.offer.to === user.uid) {
            handleIncomingCall(sessionId, sessionData.offer)
          }
        })
      }
    })

    return () => off(incomingCallsRef)
  }, [user])

  const handleIncomingCall = async (sessionId: string, offerData: any) => {
    try {
      // Create peer connection for incoming call
      peerConnection.current = new RTCPeerConnection(configuration)

      // Handle remote stream
      peerConnection.current.ontrack = (event) => {
        console.log("Received remote stream")
        setIsReceiving(true)
        // Auto-play remote audio stream
        const remoteAudio = new Audio()
        remoteAudio.srcObject = event.streams[0]
        remoteAudio.play()
      }

      // Set remote description
      await peerConnection.current.setRemoteDescription(offerData.offer)

      // Create and send answer
      const answer = await peerConnection.current.createAnswer()
      await peerConnection.current.setLocalDescription(answer)

      await set(ref(realtimeDb, `signaling/${sessionId}/answer`), {
        answer: answer,
        from: user.uid,
        to: offerData.from,
        timestamp: Date.now(),
      })

      // Handle ICE candidates
      peerConnection.current.onicecandidate = (event) => {
        if (event.candidate) {
          const candidateRef = ref(realtimeDb, `signaling/${sessionId}/candidates`)
          push(candidateRef, {
            candidate: event.candidate,
            from: user.uid,
            timestamp: Date.now(),
          })
        }
      }
    } catch (error) {
      console.error("Error handling incoming call:", error)
    }
  }

  return (
    <WebRTCContext.Provider
      value={{
        isStreaming,
        startVoiceStream,
        stopVoiceStream,
        isReceiving,
      }}
    >
      {children}
    </WebRTCContext.Provider>
  )
}

export function useWebRTC() {
  const context = useContext(WebRTCContext)
  if (context === undefined) {
    throw new Error("useWebRTC must be used within a WebRTCProvider")
  }
  return context
}
