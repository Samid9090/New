"use client"

import { useState, useEffect } from "react"
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { collection, query, where, onSnapshot, doc, updateDoc, deleteDoc, getDoc, arrayUnion } from "firebase/firestore"
import { useAuth } from "../context/AuthContext"
import { db } from "../config/firebase"

interface FriendRequest {
  id: string
  from: string
  to: string
  method: string
  status: string
  timestamp: any
  fromUser?: {
    name: string
    username: string
    pin: string
  }
}

export default function FriendRequestsScreen() {
  const { user, userProfile, updateUserProfile } = useAuth()
  const [incomingRequests, setIncomingRequests] = useState<FriendRequest[]>([])
  const [outgoingRequests, setOutgoingRequests] = useState<FriendRequest[]>([])
  const [activeTab, setActiveTab] = useState<"incoming" | "outgoing">("incoming")

  useEffect(() => {
    if (user) {
      loadFriendRequests()
    }
  }, [user])

  const loadFriendRequests = () => {
    if (!user) return

    // Listen to incoming requests
    const incomingQuery = query(
      collection(db, "friend_requests"),
      where("to", "==", user.uid),
      where("status", "==", "pending"),
    )

    const unsubscribeIncoming = onSnapshot(incomingQuery, async (snapshot) => {
      const requests: FriendRequest[] = []

      for (const doc of snapshot.docs) {
        const data = doc.data()
        const fromUserDoc = await getDoc(doc(db, "users", data.from))
        const fromUserData = fromUserDoc.data()

        requests.push({
          id: doc.id,
          ...data,
          fromUser: fromUserData
            ? {
                name: fromUserData.name,
                username: fromUserData.username,
                pin: fromUserData.pin,
              }
            : undefined,
        } as FriendRequest)
      }

      setIncomingRequests(requests)
    })

    // Listen to outgoing requests
    const outgoingQuery = query(
      collection(db, "friend_requests"),
      where("from", "==", user.uid),
      where("status", "==", "pending"),
    )

    const unsubscribeOutgoing = onSnapshot(outgoingQuery, async (snapshot) => {
      const requests: FriendRequest[] = []

      for (const doc of snapshot.docs) {
        const data = doc.data()
        const toUserDoc = await getDoc(doc(db, "users", data.to))
        const toUserData = toUserDoc.data()

        requests.push({
          id: doc.id,
          ...data,
          fromUser: toUserData
            ? {
                name: toUserData.name,
                username: toUserData.username,
                pin: toUserData.pin,
              }
            : undefined,
        } as FriendRequest)
      }

      setOutgoingRequests(requests)
    })

    return () => {
      unsubscribeIncoming()
      unsubscribeOutgoing()
    }
  }

  const acceptRequest = async (request: FriendRequest) => {
    try {
      // Update request status
      await updateDoc(doc(db, "friend_requests", request.id), {
        status: "accepted",
      })

      // Add to both users' friends list
      await updateDoc(doc(db, "users", user!.uid), {
        friends: arrayUnion(request.from),
      })

      await updateDoc(doc(db, "users", request.from), {
        friends: arrayUnion(user!.uid),
      })

      // Update local state
      if (userProfile) {
        updateUserProfile({
          friends: [...userProfile.friends, request.from],
        })
      }

      Alert.alert("Success", "Friend request accepted!")
    } catch (error) {
      console.error("Error accepting request:", error)
      Alert.alert("Error", "Failed to accept friend request")
    }
  }

  const rejectRequest = async (requestId: string) => {
    try {
      await deleteDoc(doc(db, "friend_requests", requestId))
      Alert.alert("Success", "Friend request rejected")
    } catch (error) {
      console.error("Error rejecting request:", error)
      Alert.alert("Error", "Failed to reject friend request")
    }
  }

  const cancelRequest = async (requestId: string) => {
    try {
      await deleteDoc(doc(db, "friend_requests", requestId))
      Alert.alert("Success", "Friend request cancelled")
    } catch (error) {
      console.error("Error cancelling request:", error)
      Alert.alert("Error", "Failed to cancel friend request")
    }
  }

  const renderIncomingRequest = ({ item }: { item: FriendRequest }) => (
    <View style={styles.requestItem}>
      <View style={styles.requestInfo}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{item.fromUser?.name.charAt(0).toUpperCase()}</Text>
        </View>

        <View style={styles.requestDetails}>
          <Text style={styles.requestName}>{item.fromUser?.name}</Text>
          <Text style={styles.requestUsername}>@{item.fromUser?.username}</Text>
          <Text style={styles.requestMethod}>
            via {item.method === "username" ? "Username" : item.method === "pin" ? "PIN" : "QR Code"}
          </Text>
        </View>
      </View>

      <View style={styles.requestActions}>
        <TouchableOpacity style={[styles.actionButton, styles.acceptButton]} onPress={() => acceptRequest(item)}>
          <Ionicons name="checkmark" size={20} color="white" />
        </TouchableOpacity>

        <TouchableOpacity style={[styles.actionButton, styles.rejectButton]} onPress={() => rejectRequest(item.id)}>
          <Ionicons name="close" size={20} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  )

  const renderOutgoingRequest = ({ item }: { item: FriendRequest }) => (
    <View style={styles.requestItem}>
      <View style={styles.requestInfo}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{item.fromUser?.name.charAt(0).toUpperCase()}</Text>
        </View>

        <View style={styles.requestDetails}>
          <Text style={styles.requestName}>{item.fromUser?.name}</Text>
          <Text style={styles.requestUsername}>@{item.fromUser?.username}</Text>
          <Text style={styles.requestMethod}>
            via {item.method === "username" ? "Username" : item.method === "pin" ? "PIN" : "QR Code"}
          </Text>
        </View>
      </View>

      <TouchableOpacity style={[styles.actionButton, styles.cancelButton]} onPress={() => cancelRequest(item.id)}>
        <Text style={styles.cancelButtonText}>Cancel</Text>
      </TouchableOpacity>
    </View>
  )

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Friend Requests</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "incoming" && styles.activeTab]}
          onPress={() => setActiveTab("incoming")}
        >
          <Text style={[styles.tabText, activeTab === "incoming" && styles.activeTabText]}>
            Incoming ({incomingRequests.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === "outgoing" && styles.activeTab]}
          onPress={() => setActiveTab("outgoing")}
        >
          <Text style={[styles.tabText, activeTab === "outgoing" && styles.activeTabText]}>
            Sent ({outgoingRequests.length})
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        {activeTab === "incoming" ? (
          incomingRequests.length === 0 ? (
            <View style={styles.emptyState}>
              <Ionicons name="mail-outline" size={80} color="#ccc" />
              <Text style={styles.emptyTitle}>No incoming requests</Text>
              <Text style={styles.emptySubtitle}>Friend requests will appear here</Text>
            </View>
          ) : (
            <FlatList
              data={incomingRequests}
              renderItem={renderIncomingRequest}
              keyExtractor={(item) => item.id}
              showsVerticalScrollIndicator={false}
            />
          )
        ) : outgoingRequests.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="paper-plane-outline" size={80} color="#ccc" />
            <Text style={styles.emptyTitle}>No sent requests</Text>
            <Text style={styles.emptySubtitle}>Requests you send will appear here</Text>
          </View>
        ) : (
          <FlatList
            data={outgoingRequests}
            renderItem={renderOutgoingRequest}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: "white",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
  },
  tabs: {
    flexDirection: "row",
    backgroundColor: "white",
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginHorizontal: 4,
    alignItems: "center",
  },
  activeTab: {
    backgroundColor: "#f0f8ff",
  },
  tabText: {
    fontSize: 14,
    color: "#666",
  },
  activeTabText: {
    color: "#007AFF",
    fontWeight: "600",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  requestItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "white",
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  requestInfo: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#007AFF",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },
  avatarText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  requestDetails: {
    flex: 1,
  },
  requestName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  requestUsername: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  requestMethod: {
    fontSize: 12,
    color: "#999",
    marginTop: 2,
  },
  requestActions: {
    flexDirection: "row",
    gap: 10,
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  acceptButton: {
    backgroundColor: "#4CAF50",
  },
  rejectButton: {
    backgroundColor: "#FF3B30",
  },
  cancelButton: {
    backgroundColor: "#FF9500",
    paddingHorizontal: 15,
    width: "auto",
  },
  cancelButtonText: {
    color: "white",
    fontSize: 14,
    fontWeight: "600",
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#333",
    marginTop: 20,
  },
  emptySubtitle: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    marginTop: 10,
    lineHeight: 20,
  },
})
