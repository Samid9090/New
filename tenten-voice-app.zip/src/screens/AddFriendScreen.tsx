"use client"

import { useState } from "react"
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { collection, query, where, getDocs, addDoc } from "firebase/firestore"
import { useAuth } from "../context/AuthContext"
import { db } from "../config/firebase"

export default function AddFriendScreen() {
  const { user, userProfile } = useAuth()
  const [activeTab, setActiveTab] = useState<"username" | "pin" | "qr">("username")
  const [searchValue, setSearchValue] = useState("")
  const [loading, setLoading] = useState(false)

  const sendFriendRequest = async (targetUserId: string, method: string) => {
    if (!user || !userProfile) return

    try {
      await addDoc(collection(db, "friend_requests"), {
        from: user.uid,
        to: targetUserId,
        method,
        status: "pending",
        timestamp: new Date(),
      })

      Alert.alert("Success", "Friend request sent!")
      setSearchValue("")
    } catch (error) {
      console.error("Error sending friend request:", error)
      Alert.alert("Error", "Failed to send friend request")
    }
  }

  const searchByUsername = async () => {
    if (!searchValue.trim()) {
      Alert.alert("Error", "Please enter a username")
      return
    }

    setLoading(true)
    try {
      const q = query(collection(db, "users"), where("username", "==", searchValue.toLowerCase().trim()))
      const querySnapshot = await getDocs(q)

      if (querySnapshot.empty) {
        Alert.alert("Not Found", "No user found with this username")
      } else {
        const userData = querySnapshot.docs[0].data()
        if (userData.uid === user?.uid) {
          Alert.alert("Error", "You can't add yourself as a friend")
        } else {
          Alert.alert("User Found", `Send friend request to ${userData.name} (@${userData.username})?`, [
            { text: "Cancel", style: "cancel" },
            { text: "Send Request", onPress: () => sendFriendRequest(userData.uid, "username") },
          ])
        }
      }
    } catch (error) {
      console.error("Error searching user:", error)
      Alert.alert("Error", "Failed to search user")
    } finally {
      setLoading(false)
    }
  }

  const searchByPin = async () => {
    if (!searchValue.trim() || searchValue.length !== 4) {
      Alert.alert("Error", "Please enter a valid 4-digit PIN")
      return
    }

    setLoading(true)
    try {
      const q = query(collection(db, "users"), where("pin", "==", searchValue.trim()))
      const querySnapshot = await getDocs(q)

      if (querySnapshot.empty) {
        Alert.alert("Not Found", "No user found with this PIN")
      } else {
        const userData = querySnapshot.docs[0].data()
        if (userData.uid === user?.uid) {
          Alert.alert("Error", "You can't add yourself as a friend")
        } else {
          Alert.alert("User Found", `Send friend request to ${userData.name} (PIN: ${userData.pin})?`, [
            { text: "Cancel", style: "cancel" },
            { text: "Send Request", onPress: () => sendFriendRequest(userData.uid, "pin") },
          ])
        }
      }
    } catch (error) {
      console.error("Error searching user:", error)
      Alert.alert("Error", "Failed to search user")
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    if (activeTab === "username") {
      searchByUsername()
    } else if (activeTab === "pin") {
      searchByPin()
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Add Friend</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "username" && styles.activeTab]}
          onPress={() => setActiveTab("username")}
        >
          <Ionicons name="person" size={20} color={activeTab === "username" ? "#007AFF" : "#666"} />
          <Text style={[styles.tabText, activeTab === "username" && styles.activeTabText]}>Username</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === "pin" && styles.activeTab]}
          onPress={() => setActiveTab("pin")}
        >
          <Ionicons name="keypad" size={20} color={activeTab === "pin" ? "#007AFF" : "#666"} />
          <Text style={[styles.tabText, activeTab === "pin" && styles.activeTabText]}>PIN</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === "qr" && styles.activeTab]}
          onPress={() => setActiveTab("qr")}
        >
          <Ionicons name="qr-code" size={20} color={activeTab === "qr" ? "#007AFF" : "#666"} />
          <Text style={[styles.tabText, activeTab === "qr" && styles.activeTabText]}>QR Code</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content}>
        {activeTab === "username" && (
          <View style={styles.searchContainer}>
            <Text style={styles.sectionTitle}>Search by Username</Text>
            <Text style={styles.sectionSubtitle}>Enter the exact username to find your friend</Text>

            <View style={styles.inputContainer}>
              <Ionicons name="at" size={20} color="#666" style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Enter username"
                value={searchValue}
                onChangeText={setSearchValue}
                autoCapitalize="none"
              />
            </View>

            <TouchableOpacity
              style={[styles.searchButton, loading && styles.buttonDisabled]}
              onPress={handleSearch}
              disabled={loading}
            >
              <Text style={styles.searchButtonText}>{loading ? "Searching..." : "Search"}</Text>
            </TouchableOpacity>
          </View>
        )}

        {activeTab === "pin" && (
          <View style={styles.searchContainer}>
            <Text style={styles.sectionTitle}>Search by PIN</Text>
            <Text style={styles.sectionSubtitle}>Enter the 4-digit PIN to find your friend</Text>

            <View style={styles.inputContainer}>
              <Ionicons name="keypad" size={20} color="#666" style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Enter 4-digit PIN"
                value={searchValue}
                onChangeText={setSearchValue}
                keyboardType="numeric"
                maxLength={4}
              />
            </View>

            <TouchableOpacity
              style={[styles.searchButton, loading && styles.buttonDisabled]}
              onPress={handleSearch}
              disabled={loading}
            >
              <Text style={styles.searchButtonText}>{loading ? "Searching..." : "Search"}</Text>
            </TouchableOpacity>
          </View>
        )}

        {activeTab === "qr" && (
          <View style={styles.searchContainer}>
            <Text style={styles.sectionTitle}>QR Code Scanner</Text>
            <Text style={styles.sectionSubtitle}>Scan your friend's QR code to add them instantly</Text>

            <TouchableOpacity style={styles.qrButton}>
              <Ionicons name="camera" size={40} color="#007AFF" />
              <Text style={styles.qrButtonText}>Open Camera</Text>
            </TouchableOpacity>

            <Text style={styles.orText}>OR</Text>

            <TouchableOpacity style={styles.qrButton}>
              <Ionicons name="image" size={40} color="#007AFF" />
              <Text style={styles.qrButtonText}>Choose from Gallery</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: "white",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
  },
  tabs: {
    flexDirection: "row",
    backgroundColor: "white",
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  tab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  activeTab: {
    backgroundColor: "#f0f8ff",
  },
  tabText: {
    marginLeft: 8,
    fontSize: 14,
    color: "#666",
  },
  activeTabText: {
    color: "#007AFF",
    fontWeight: "600",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  searchContainer: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: "#666",
    marginBottom: 20,
    lineHeight: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 20,
  },
  inputIcon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    paddingVertical: 15,
    fontSize: 16,
  },
  searchButton: {
    backgroundColor: "#007AFF",
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  searchButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  qrButton: {
    alignItems: "center",
    paddingVertical: 30,
    borderWidth: 2,
    borderColor: "#007AFF",
    borderStyle: "dashed",
    borderRadius: 12,
    marginBottom: 20,
  },
  qrButtonText: {
    color: "#007AFF",
    fontSize: 16,
    fontWeight: "600",
    marginTop: 10,
  },
  orText: {
    textAlign: "center",
    color: "#666",
    fontSize: 14,
    marginVertical: 10,
  },
})
