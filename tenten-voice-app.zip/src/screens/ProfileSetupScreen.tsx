"use client"

import { useState, useEffect } from "react"
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native"
import { doc, updateDoc } from "firebase/firestore"
import { useAuth } from "../context/AuthContext"
import { db } from "../config/firebase"

export default function ProfileSetupScreen({ navigation }: any) {
  const { user, userProfile } = useAuth()
  const [name, setName] = useState("")
  const [username, setUsername] = useState("")
  const [pin, setPin] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (userProfile) {
      setName(userProfile.name || "")
      setUsername(userProfile.username || "")
      setPin(userProfile.pin || "")

      // If profile is already complete, navigate to mic permission
      if (userProfile.name && userProfile.username) {
        navigation.replace("MicPermission")
      }
    }
  }, [userProfile])

  const checkUsernameAvailable = async (username: string) => {
    // This would need a cloud function or more complex query
    // For now, we'll assume it's available
    return true
  }

  const handleSaveProfile = async () => {
    if (!name.trim() || !username.trim()) {
      Alert.alert("Error", "Please fill in all fields")
      return
    }

    if (username.length < 3) {
      Alert.alert("Error", "Username must be at least 3 characters")
      return
    }

    setLoading(true)
    try {
      const isAvailable = await checkUsernameAvailable(username)
      if (!isAvailable) {
        Alert.alert("Error", "Username is already taken")
        setLoading(false)
        return
      }

      if (user) {
        await updateDoc(doc(db, "users", user.uid), {
          name: name.trim(),
          username: username.toLowerCase().trim(),
          pin,
        })

        navigation.replace("MicPermission")
      }
    } catch (error: any) {
      Alert.alert("Error", error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Setup Your Profile</Text>
        <Text style={styles.subtitle}>Let's get you started</Text>

        <View style={styles.avatarContainer}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>📱</Text>
          </View>
          <TouchableOpacity style={styles.changePhotoButton}>
            <Text style={styles.changePhotoText}>Add Photo</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.form}>
          <TextInput style={styles.input} placeholder="Full Name" value={name} onChangeText={setName} />

          <TextInput
            style={styles.input}
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
          />

          <View style={styles.pinContainer}>
            <Text style={styles.pinLabel}>Your PIN:</Text>
            <Text style={styles.pinValue}>{pin}</Text>
          </View>

          <TouchableOpacity
            style={[styles.button, loading && styles.buttonDisabled]}
            onPress={handleSaveProfile}
            disabled={loading}
          >
            <Text style={styles.buttonText}>{loading ? "Saving..." : "Continue"}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
    color: "#333",
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 40,
    color: "#666",
  },
  avatarContainer: {
    alignItems: "center",
    marginBottom: 30,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#007AFF",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
  },
  avatarText: {
    fontSize: 40,
  },
  changePhotoButton: {
    paddingHorizontal: 20,
    paddingVertical: 8,
    backgroundColor: "#f0f0f0",
    borderRadius: 20,
  },
  changePhotoText: {
    color: "#007AFF",
    fontSize: 14,
  },
  form: {
    gap: 20,
  },
  input: {
    backgroundColor: "white",
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 10,
    fontSize: 16,
    borderWidth: 1,
    borderColor: "#ddd",
  },
  pinContainer: {
    backgroundColor: "white",
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#ddd",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  pinLabel: {
    fontSize: 16,
    color: "#666",
  },
  pinValue: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#007AFF",
  },
  button: {
    backgroundColor: "#007AFF",
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
})
