"use client"

import React from "react"
import { View, Text, TouchableOpacity, StyleSheet, Alert, ScrollView, Switch } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { signOut } from "firebase/auth"
import { useAuth } from "../context/AuthContext"
import { auth } from "../config/firebase"

export default function SettingsScreen() {
  const { userProfile } = useAuth()
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(true)
  const [micEnabled, setMicEnabled] = React.useState(true)

  const handleLogout = () => {
    Alert.alert("Logout", "Are you sure you want to logout?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Logout",
        style: "destructive",
        onPress: () => signOut(auth),
      },
    ])
  }

  const copyPin = () => {
    Alert.alert("PIN Copied", `Your PIN ${userProfile?.pin} has been copied to clipboard`)
  }

  const shareProfile = () => {
    Alert.alert("Share Profile", "Profile sharing functionality will be implemented")
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Settings</Text>
      </View>

      <ScrollView style={styles.content}>
        {/* Profile Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profile</Text>

          <View style={styles.profileCard}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{userProfile?.name.charAt(0).toUpperCase()}</Text>
            </View>

            <View style={styles.profileInfo}>
              <Text style={styles.profileName}>{userProfile?.name}</Text>
              <Text style={styles.profileUsername}>@{userProfile?.username}</Text>
              <Text style={styles.profileEmail}>{userProfile?.email}</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.settingItem} onPress={copyPin}>
            <View style={styles.settingLeft}>
              <Ionicons name="keypad" size={20} color="#007AFF" />
              <Text style={styles.settingText}>My PIN</Text>
            </View>
            <View style={styles.settingRight}>
              <Text style={styles.pinValue}>{userProfile?.pin}</Text>
              <Ionicons name="copy" size={16} color="#666" />
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem} onPress={shareProfile}>
            <View style={styles.settingLeft}>
              <Ionicons name="share" size={20} color="#007AFF" />
              <Text style={styles.settingText}>Share Profile</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color="#666" />
          </TouchableOpacity>
        </View>

        {/* Preferences Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Preferences</Text>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name="notifications" size={20} color="#007AFF" />
              <Text style={styles.settingText}>Push Notifications</Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: "#ccc", true: "#007AFF" }}
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name="mic" size={20} color="#007AFF" />
              <Text style={styles.settingText}>Microphone Access</Text>
            </View>
            <Switch value={micEnabled} onValueChange={setMicEnabled} trackColor={{ false: "#ccc", true: "#007AFF" }} />
          </View>
        </View>

        {/* About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About</Text>

          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name="help-circle" size={20} color="#007AFF" />
              <Text style={styles.settingText}>Help & Support</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color="#666" />
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name="document-text" size={20} color="#007AFF" />
              <Text style={styles.settingText}>Privacy Policy</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color="#666" />
          </TouchableOpacity>

          <TouchableOpacity style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name="information-circle" size={20} color="#007AFF" />
              <Text style={styles.settingText}>About TenTen Voice</Text>
            </View>
            <Ionicons name="chevron-forward" size={16} color="#666" />
          </TouchableOpacity>
        </View>

        {/* Logout Section */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Ionicons name="log-out" size={20} color="#FF3B30" />
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: "white",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
  },
  content: {
    flex: 1,
  },
  section: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
    marginBottom: 15,
    marginHorizontal: 20,
  },
  profileCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    padding: 20,
    marginHorizontal: 20,
    borderRadius: 12,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#007AFF",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },
  avatarText: {
    color: "white",
    fontSize: 24,
    fontWeight: "bold",
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 2,
  },
  profileUsername: {
    fontSize: 14,
    color: "#666",
    marginBottom: 2,
  },
  profileEmail: {
    fontSize: 12,
    color: "#999",
  },
  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "white",
    paddingVertical: 15,
    paddingHorizontal: 20,
    marginHorizontal: 20,
    marginBottom: 1,
  },
  settingLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  settingText: {
    fontSize: 16,
    color: "#333",
    marginLeft: 15,
  },
  settingRight: {
    flexDirection: "row",
    alignItems: "center",
  },
  pinValue: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#007AFF",
    marginRight: 10,
  },
  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "white",
    paddingVertical: 15,
    marginHorizontal: 20,
    borderRadius: 12,
  },
  logoutText: {
    fontSize: 16,
    color: "#FF3B30",
    fontWeight: "600",
    marginLeft: 10,
  },
})
