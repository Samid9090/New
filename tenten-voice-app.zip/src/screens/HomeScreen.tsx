"use client"

import { useState, useEffect } from "react"
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { doc, getDoc } from "firebase/firestore"
import { useAuth } from "../context/AuthContext"
import { useWebRTC } from "../context/WebRTCContext"
import { db } from "../config/firebase"

interface Friend {
  uid: string
  name: string
  username: string
  online: boolean
  profilePic?: string
}

export default function HomeScreen() {
  const { userProfile } = useAuth()
  const { isStreaming, startVoiceStream, stopVoiceStream } = useWebRTC()
  const [friends, setFriends] = useState<Friend[]>([])
  const [streamingTo, setStreamingTo] = useState<string | null>(null)

  useEffect(() => {
    if (userProfile?.friends) {
      loadFriends()
    }
  }, [userProfile])

  const loadFriends = async () => {
    if (!userProfile?.friends) return

    try {
      const friendsData: Friend[] = []

      for (const friendId of userProfile.friends) {
        const friendDoc = await getDoc(doc(db, "users", friendId))
        if (friendDoc.exists()) {
          const data = friendDoc.data()
          friendsData.push({
            uid: data.uid,
            name: data.name,
            username: data.username,
            online: data.online || false,
            profilePic: data.profilePic,
          })
        }
      }

      setFriends(friendsData)
    } catch (error) {
      console.error("Error loading friends:", error)
    }
  }

  const handleVoicePress = async (friendId: string) => {
    if (isStreaming && streamingTo === friendId) {
      stopVoiceStream()
      setStreamingTo(null)
    } else {
      try {
        await startVoiceStream(friendId)
        setStreamingTo(friendId)
      } catch (error) {
        Alert.alert("Error", "Failed to start voice stream")
      }
    }
  }

  const renderFriend = ({ item }: { item: Friend }) => (
    <View style={styles.friendItem}>
      <View style={styles.friendInfo}>
        <View style={styles.avatarContainer}>
          <View style={[styles.avatar, { backgroundColor: item.online ? "#4CAF50" : "#ccc" }]}>
            <Text style={styles.avatarText}>{item.name.charAt(0).toUpperCase()}</Text>
          </View>
          {item.online && <View style={styles.onlineIndicator} />}
        </View>

        <View style={styles.friendDetails}>
          <Text style={styles.friendName}>{item.name}</Text>
          <Text style={styles.friendUsername}>@{item.username}</Text>
        </View>
      </View>

      <TouchableOpacity
        style={[styles.voiceButton, isStreaming && streamingTo === item.uid && styles.voiceButtonActive]}
        onPress={() => handleVoicePress(item.uid)}
        disabled={!item.online}
      >
        <Ionicons
          name={isStreaming && streamingTo === item.uid ? "stop" : "mic"}
          size={24}
          color={item.online ? "white" : "#ccc"}
        />
      </TouchableOpacity>
    </View>
  )

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Friends</Text>
        <Text style={styles.subtitle}>Tap and hold to talk</Text>
      </View>

      {friends.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="people-outline" size={80} color="#ccc" />
          <Text style={styles.emptyTitle}>No friends yet</Text>
          <Text style={styles.emptySubtitle}>Add friends using username, PIN, or QR code</Text>
        </View>
      ) : (
        <FlatList
          data={friends}
          renderItem={renderFriend}
          keyExtractor={(item) => item.uid}
          contentContainerStyle={styles.friendsList}
        />
      )}

      {isStreaming && (
        <View style={styles.streamingIndicator}>
          <View style={styles.waveform}>
            <View style={[styles.wave, styles.wave1]} />
            <View style={[styles.wave, styles.wave2]} />
            <View style={[styles.wave, styles.wave3]} />
            <View style={[styles.wave, styles.wave4]} />
          </View>
          <Text style={styles.streamingText}>Streaming...</Text>
        </View>
      )}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: "white",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
  },
  subtitle: {
    fontSize: 14,
    color: "#666",
    marginTop: 5,
  },
  friendsList: {
    padding: 20,
  },
  friendItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "white",
    padding: 15,
    borderRadius: 12,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  friendInfo: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  avatarContainer: {
    position: "relative",
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },
  avatarText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  onlineIndicator: {
    position: "absolute",
    bottom: 2,
    right: 12,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: "#4CAF50",
    borderWidth: 2,
    borderColor: "white",
  },
  friendDetails: {
    flex: 1,
  },
  friendName: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  friendUsername: {
    fontSize: 14,
    color: "#666",
    marginTop: 2,
  },
  voiceButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#007AFF",
    justifyContent: "center",
    alignItems: "center",
  },
  voiceButtonActive: {
    backgroundColor: "#FF3B30",
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "600",
    color: "#333",
    marginTop: 20,
  },
  emptySubtitle: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    marginTop: 10,
    lineHeight: 20,
  },
  streamingIndicator: {
    position: "absolute",
    bottom: 100,
    left: 20,
    right: 20,
    backgroundColor: "#007AFF",
    padding: 20,
    borderRadius: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  waveform: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 15,
  },
  wave: {
    width: 4,
    backgroundColor: "white",
    marginHorizontal: 2,
    borderRadius: 2,
  },
  wave1: {
    height: 20,
  },
  wave2: {
    height: 30,
  },
  wave3: {
    height: 25,
  },
  wave4: {
    height: 35,
  },
  streamingText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
})
