"use client"

import { useState } from "react"
import { View, Text, TouchableOpacity, StyleSheet, Alert } from "react-native"
import { request, PERMISSIONS, RESULTS } from "react-native-permissions"
import { Ionicons } from "@expo/vector-icons"

export default function MicPermissionScreen({ navigation }: any) {
  const [loading, setLoading] = useState(false)

  const requestMicPermission = async () => {
    setLoading(true)
    try {
      const result = await request(PERMISSIONS.ANDROID.RECORD_AUDIO)

      if (result === RESULTS.GRANTED) {
        navigation.replace("Main")
      } else {
        Alert.alert(
          "Permission Required",
          "Microphone permission is required for voice streaming. You can enable it later in settings.",
          [
            { text: "Skip", onPress: () => navigation.replace("Main") },
            { text: "Try Again", onPress: requestMicPermission },
          ],
        )
      }
    } catch (error) {
      console.error("Permission error:", error)
      navigation.replace("Main")
    } finally {
      setLoading(false)
    }
  }

  const skipPermission = () => {
    navigation.replace("Main")
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Ionicons name="mic" size={80} color="#007AFF" />
        </View>

        <Text style={styles.title}>Microphone Access</Text>
        <Text style={styles.subtitle}>Allow microphone access to send voice messages to your friends instantly</Text>

        <View style={styles.features}>
          <View style={styles.feature}>
            <Ionicons name="checkmark-circle" size={24} color="#4CAF50" />
            <Text style={styles.featureText}>Real-time voice streaming</Text>
          </View>
          <View style={styles.feature}>
            <Ionicons name="checkmark-circle" size={24} color="#4CAF50" />
            <Text style={styles.featureText}>Crystal clear audio quality</Text>
          </View>
          <View style={styles.feature}>
            <Ionicons name="checkmark-circle" size={24} color="#4CAF50" />
            <Text style={styles.featureText}>Instant push-to-talk</Text>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={requestMicPermission}
          disabled={loading}
        >
          <Text style={styles.buttonText}>{loading ? "Requesting..." : "Allow Microphone"}</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.skipButton} onPress={skipPermission}>
          <Text style={styles.skipText}>Skip for now</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  content: {
    flex: 1,
    justifyContent: "center",
    paddingHorizontal: 30,
  },
  iconContainer: {
    alignItems: "center",
    marginBottom: 30,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 15,
    color: "#333",
  },
  subtitle: {
    fontSize: 16,
    textAlign: "center",
    marginBottom: 40,
    color: "#666",
    lineHeight: 24,
  },
  features: {
    marginBottom: 40,
  },
  feature: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  featureText: {
    marginLeft: 15,
    fontSize: 16,
    color: "#333",
  },
  button: {
    backgroundColor: "#007AFF",
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 15,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
  skipButton: {
    alignItems: "center",
    paddingVertical: 10,
  },
  skipText: {
    color: "#666",
    fontSize: 14,
  },
})
