"use client"

import { useState } from "react"
import { View, Text, TouchableOpacity, StyleSheet, Share, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import QRCode from "react-native-qrcode-svg"
import { useAuth } from "../context/AuthContext"

export default function QRScreen() {
  const { userProfile } = useAuth()
  const [activeTab, setActiveTab] = useState<"my-qr" | "scan">("my-qr")

  const qrData = JSON.stringify({
    uid: userProfile?.uid,
    username: userProfile?.username,
    pin: userProfile?.pin,
    name: userProfile?.name,
  })

  const shareQR = async () => {
    try {
      await Share.share({
        message: `Add me on TenTen Voice!\nUsername: ${userProfile?.username}\nPIN: ${userProfile?.pin}`,
        title: "Add me on TenTen Voice",
      })
    } catch (error) {
      console.error("Error sharing:", error)
    }
  }

  const openCamera = () => {
    Alert.alert("Camera", "QR Scanner will be implemented here")
  }

  const openGallery = () => {
    Alert.alert("Gallery", "QR Scanner from gallery will be implemented here")
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>QR Code</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === "my-qr" && styles.activeTab]}
          onPress={() => setActiveTab("my-qr")}
        >
          <Ionicons name="qr-code" size={20} color={activeTab === "my-qr" ? "#007AFF" : "#666"} />
          <Text style={[styles.tabText, activeTab === "my-qr" && styles.activeTabText]}>My QR</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === "scan" && styles.activeTab]}
          onPress={() => setActiveTab("scan")}
        >
          <Ionicons name="camera" size={20} color={activeTab === "scan" ? "#007AFF" : "#666"} />
          <Text style={[styles.tabText, activeTab === "scan" && styles.activeTabText]}>Scan</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        {activeTab === "my-qr" ? (
          <View style={styles.qrContainer}>
            <Text style={styles.sectionTitle}>My QR Code</Text>
            <Text style={styles.sectionSubtitle}>Let friends scan this code to add you instantly</Text>

            <View style={styles.qrCodeContainer}>
              <QRCode value={qrData} size={200} color="#333" backgroundColor="white" />
            </View>

            <View style={styles.userInfo}>
              <Text style={styles.userName}>{userProfile?.name}</Text>
              <Text style={styles.userUsername}>@{userProfile?.username}</Text>
              <Text style={styles.userPin}>PIN: {userProfile?.pin}</Text>
            </View>

            <TouchableOpacity style={styles.shareButton} onPress={shareQR}>
              <Ionicons name="share" size={20} color="white" />
              <Text style={styles.shareButtonText}>Share QR Code</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.scanContainer}>
            <Text style={styles.sectionTitle}>Scan QR Code</Text>
            <Text style={styles.sectionSubtitle}>Scan your friend's QR code to add them instantly</Text>

            <TouchableOpacity style={styles.scanButton} onPress={openCamera}>
              <Ionicons name="camera" size={60} color="#007AFF" />
              <Text style={styles.scanButtonText}>Open Camera</Text>
              <Text style={styles.scanButtonSubtext}>Tap to scan QR code</Text>
            </TouchableOpacity>

            <Text style={styles.orText}>OR</Text>

            <TouchableOpacity style={styles.galleryButton} onPress={openGallery}>
              <Ionicons name="image" size={24} color="#007AFF" />
              <Text style={styles.galleryButtonText}>Choose from Gallery</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: "white",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#333",
  },
  tabs: {
    flexDirection: "row",
    backgroundColor: "white",
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  tab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  activeTab: {
    backgroundColor: "#f0f8ff",
  },
  tabText: {
    marginLeft: 8,
    fontSize: 14,
    color: "#666",
  },
  activeTabText: {
    color: "#007AFF",
    fontWeight: "600",
  },
  content: {
    flex: 1,
    padding: 20,
  },
  qrContainer: {
    backgroundColor: "white",
    padding: 30,
    borderRadius: 12,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    marginBottom: 30,
    lineHeight: 20,
  },
  qrCodeContainer: {
    padding: 20,
    backgroundColor: "white",
    borderRadius: 12,
    marginBottom: 30,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  userInfo: {
    alignItems: "center",
    marginBottom: 30,
  },
  userName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  userUsername: {
    fontSize: 16,
    color: "#666",
    marginBottom: 5,
  },
  userPin: {
    fontSize: 14,
    color: "#007AFF",
    fontWeight: "600",
  },
  shareButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#007AFF",
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 10,
  },
  shareButtonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
    marginLeft: 10,
  },
  scanContainer: {
    backgroundColor: "white",
    padding: 30,
    borderRadius: 12,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  scanButton: {
    alignItems: "center",
    paddingVertical: 40,
    paddingHorizontal: 30,
    borderWidth: 2,
    borderColor: "#007AFF",
    borderStyle: "dashed",
    borderRadius: 12,
    marginBottom: 20,
    width: "100%",
  },
  scanButtonText: {
    color: "#007AFF",
    fontSize: 18,
    fontWeight: "600",
    marginTop: 15,
  },
  scanButtonSubtext: {
    color: "#666",
    fontSize: 14,
    marginTop: 5,
  },
  orText: {
    color: "#666",
    fontSize: 14,
    marginVertical: 20,
  },
  galleryButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 15,
    paddingHorizontal: 20,
    backgroundColor: "#f0f8ff",
    borderRadius: 10,
  },
  galleryButtonText: {
    color: "#007AFF",
    fontSize: 16,
    fontWeight: "600",
    marginLeft: 10,
  },
})
