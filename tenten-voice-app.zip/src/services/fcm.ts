import { getMessaging, getToken, onMessage } from "firebase/messaging"
import { doc, updateDoc } from "firebase/firestore"
import { db } from "../config/firebase"

// Initialize Firebase Cloud Messaging
const messaging = getMessaging()

// Request notification permission and get FCM token
export const requestNotificationPermission = async (userId: string) => {
  try {
    const permission = await Notification.requestPermission()

    if (permission === "granted") {
      const token = await getToken(messaging, {
        vapidKey: "YOUR_VAPID_KEY", // Add your VAPID key from Firebase Console
      })

      if (token) {
        // Save FCM token to user profile
        await updateDoc(doc(db, "users", userId), {
          fcmToken: token,
        })

        console.log("FCM Token:", token)
        return token
      }
    } else {
      console.log("Notification permission denied")
    }
  } catch (error) {
    console.error("Error getting FCM token:", error)
  }
}

// Listen for foreground messages
export const setupForegroundMessageListener = () => {
  onMessage(messaging, (payload) => {
    console.log("Foreground message received:", payload)

    // Show notification or handle message
    if (payload.notification) {
      new Notification(payload.notification.title || "New Message", {
        body: payload.notification.body,
        icon: payload.notification.icon,
      })
    }
  })
}

// Send push notification (this would typically be done via Firebase Functions)
export const sendPushNotification = async (targetToken: string, title: string, body: string, data?: any) => {
  try {
    // This would be implemented via Firebase Functions or your backend
    const response = await fetch("https://fcm.googleapis.com/fcm/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "key=YOUR_SERVER_KEY", // Add your Firebase Server Key
      },
      body: JSON.stringify({
        to: targetToken,
        notification: {
          title,
          body,
          icon: "/icon-192x192.png",
        },
        data: data || {},
      }),
    })

    return response.json()
  } catch (error) {
    console.error("Error sending push notification:", error)
  }
}
