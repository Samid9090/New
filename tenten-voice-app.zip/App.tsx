"use client"

import { useEffect, useState } from "react"
import { NavigationContainer } from "@react-navigation/native"
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs"
import { createStackNavigator } from "@react-navigation/stack"
import { StatusBar } from "expo-status-bar"
import { View, ActivityIndicator } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { onAuthStateChanged, type User } from "firebase/auth"
import { auth } from "./src/config/firebase"
import { AuthProvider } from "./src/context/AuthContext"
import { WebRTCProvider } from "./src/context/WebRTCContext"

// Screens
import AuthScreen from "./src/screens/AuthScreen"
import ProfileSetupScreen from "./src/screens/ProfileSetupScreen"
import HomeScreen from "./src/screens/HomeScreen"
import AddFriendScreen from "./src/screens/AddFriendScreen"
import FriendRequestsScreen from "./src/screens/FriendRequestsScreen"
import QRScreen from "./src/screens/QRScreen"
import SettingsScreen from "./src/screens/SettingsScreen"
import MicPermissionScreen from "./src/screens/MicPermissionScreen"

const Tab = createBottomTabNavigator()
const Stack = createStackNavigator()

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap

          if (route.name === "Friends") {
            iconName = focused ? "people" : "people-outline"
          } else if (route.name === "Add") {
            iconName = focused ? "person-add" : "person-add-outline"
          } else if (route.name === "Requests") {
            iconName = focused ? "notifications" : "notifications-outline"
          } else if (route.name === "QR") {
            iconName = focused ? "qr-code" : "qr-code-outline"
          } else if (route.name === "Settings") {
            iconName = focused ? "settings" : "settings-outline"
          } else {
            iconName = "home"
          }

          return <Ionicons name={iconName} size={size} color={color} />
        },
        tabBarActiveTintColor: "#007AFF",
        tabBarInactiveTintColor: "gray",
        headerShown: false,
      })}
    >
      <Tab.Screen name="Friends" component={HomeScreen} />
      <Tab.Screen name="Add" component={AddFriendScreen} />
      <Tab.Screen name="Requests" component={FriendRequestsScreen} />
      <Tab.Screen name="QR" component={QRScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  )
}

export default function App() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user)
      setLoading(false)
    })

    return unsubscribe
  }, [])

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#007AFF" />
      </View>
    )
  }

  return (
    <AuthProvider>
      <WebRTCProvider>
        <NavigationContainer>
          <StatusBar style="auto" />
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {!user ? (
              <Stack.Screen name="Auth" component={AuthScreen} />
            ) : (
              <>
                <Stack.Screen name="ProfileSetup" component={ProfileSetupScreen} />
                <Stack.Screen name="MicPermission" component={MicPermissionScreen} />
                <Stack.Screen name="Main" component={MainTabs} />
              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </WebRTCProvider>
    </AuthProvider>
  )
}
